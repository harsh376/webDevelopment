<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Transitional//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-transitional.dtd">
<html xmlns="http://www.w3.org/1999/xhtml">
<head>
<meta http-equiv="Content-Type" content="text/html; charset=utf-8" />
<title>Untitled Document</title>

<style type="text/css">
	@import url(top_menu_style.css);
</style>

<link rel="stylesheet" href="main_menu_style.css" type="text/css" />

<style type="text/css" media="screen">
	@import url(slideshow_style.css);
</style>

<link rel="stylesheet" href="vertical_menu_style.css" type="text/css" />

<link rel="stylesheet" href="featured_style.css" type="text/css" />

<!-- JavaScripts-->
<script type="text/javascript" src="jquery-1.2.6.min.js"></script>
<script type="text/javascript" src="s3Slider.js"></script>
<script type="text/javascript">
    $(document).ready(function() {
        $('#slider').s3Slider({
            timeOut: 4000
        });
    });
</script>


</head>

<body topmargin="0" style="background-color:#E6E6E6; height:2400px;">

<center>

<div style="width:1024px; border:0px solid #000000; height:2300px; background-color:#FFFFFF;">						<!--	page div		-->

	<div style="width:1024px; border:0px solid #FF0000; height:35px; background-color:#570202;">					<!-- 	top menu div	-->
    
    	<ul class="topmenu orange">
            <li><a href="home.php" title="">Home</a></li>
            <li><a href="#" title="">Beautiful thoughts</a></li>
            <li><a href="#" title="" >Comments & Feedback</a></li>
            <li><a href="#" title="">Contact Us</a></li>
        
		</ul>	
       
    </div>																						<!-- 	end of top menu div		-->

	<div style="width:1024px; border:0px solid #000099; height:150px; background-color:none;">				<!-- 	site name div	-->
        	<img src="logo.jpg" style="float:left;" />
    </div>							<!-- 	end of site name div	-->

	<div class="main_menu" style="width:1024px; border:0px solid #006666; height:50px;">					<!-- 		main menu div		-->
    
    	<ul>
			<li><a href="beds.php">Beds</a>
            	<ul>
					<li><a href="#">Linea Gold</a></li>
					<li><a href="#">Shades of Paradise</a></li>
					<li><a href="#">Sonata Classic Coral</a></li>
					<li><a href="#">Sonata Classic Jazz</a></li>
                    <li><a href="#">Sonata Gold</a></li>
					<li><a href="#">Pillows and Cushions</a></li>
					<li><a href="#">Mattress Protector</a></li>
			   </ul>
          </li>
			<li><a href="curtains.php">Curtains</a></li>
			<li><a href="#" style="background-color:#694321;">Diwan Sets</a></li>
			<li><a href="table.php">Table Linen</a>
            	<ul>
                    <li><a href="#">Rectangle Table</a></li>
                    <li><a href="#">Round Table</a></li>
                </ul>
          </li>
            <li><a href="kitchen.php" >Kitchen Linen</a></li>
            <li><a href="storage.php" >Storage Racks</a></li>
            <li><a href="laundry.php" >Laundry Bags</a></li>
            <li><a href="accessories.php" >Accessories</a></li>
		</ul>
    
    </div>											<!-- 		end of main menu div		-->

	<div style="width:700px; height:2000px; background-color:none; float:left;">			<!-- content div	-->
    	
        <div style="width:660px; margin-left:40px; background-color:none; height:2000px; float:left;">		<!-- this div is for the left margin	-->
        	
            <br/>
        	
            <a href="home.php" style="text-decoration:none; font-family:Verdana, Arial, Helvetica, sans-serif; font-size:12px; float:left; color:#666666;">Home&nbsp;>&nbsp;</a>
        	<font style="font-family:Verdana, Arial, Helvetica, sans-serif; font-size:12px; font-weight:600px; float:left; font-weight:600; color:#666666;"> Diwan Sets</font>
            
     		<br/>
            
            <div style="line-height:50px; background-color:none; height:50px; float:left;">
                <font style="font-family:Verdana, Arial, Helvetica, sans-serif; font-size:16px; font-weight:600px; float:left; font-weight:600; vertical-align:middle;"> Diwan Sets</font>
    
                <font style="font-family:Verdana, Arial, Helvetica, sans-serif; font-size:12px; font-weight:600px; float:left; color:#666666; vertical-align:middle;">&nbsp;&nbsp;&nbsp;&nbsp;There are 6 products</font>
            </div>
			
            <div>
            	<img src="images_diwan/6-category.jpg" />
            </div>        	
            <br/>
        	<div style="width:660px; background-color:none; height:40px;">
            	
                <input type="button" name="btncompare" id="btncompare" value="Compare" style="border:0px; width:100px; height:40px; background-color:#8B0F01; color:#ffffff; float:right;"/>
                
            </div>
            <br/>
            
            <div style="width:660px; background-color:none; height:30px; line-height:30px;">		<!-- sort by div	-->
            
            	
                <select name="txtsortby" id="txtsortby" style="float:right;">
                	<option value="">--</option>
                    <option value="Pricelowest">Price : lowest first</option>
					<option value="Pricehighest">Price : highest first</option>
                    <option value="Productaz">Product : A to Z</option>
                    <option value="Productza">Product : Z to A</option>
                    <option value="Instock">In Stock first</option>
                </select>
                
                <font style="font-family:Verdana, Arial, Helvetica, sans-serif; font-size:12px; font-weight:600px; float:right; color:#666666; vertical-align:middle;">Sort by&nbsp;&nbsp;</font>
            	
                
                
            </div>																	<!-- end of sort by div	-->
            
          <div style="width:660px; height:200px; border-bottom:1px #666666 dashed; padding:20px 0px 20px 0px; background-color:none;"> <!-- item 1 div	-->
            	
              <div>
                	<img src="images_diwan/2587-home.jpg" style="float:left;" />
                    
                    <div style="width:270px; height:200px; background-color:none; float:left; margin-left:20px;">
                    	
                        <font style="font-family:Verdana, Arial, Helvetica, sans-serif; float:left; font-size:12px;">Available</font>
                        <br/><br/>
                        
                        <font style="font-family:Verdana, Arial, Helvetica, sans-serif; font-size:12px; font-weight:600px; float:left; font-weight:600; color:#666666;">Diwan-e-Khaas, Diwan-e-Shaan /...</font>
                        <br/>
                        <font style="font-family:Verdana, Arial, Helvetica, sans-serif; font-size:12px; font-weight:600px; float:left; color:#666666;">For more details click on this image</font>
                    
                    </div>
                    
                    <div style="width:150px; height:200px; background-color:none; float:right;">
                    
                    	<span class="price" style="float:left;">Rs/-1,995.00</span> 
                		<br/><br/>
                        <input type="button" name="btnatc" id="btnatc" value="Add to Cart" style="float:right; border:0px; width:150px; height:40px; background-color:#694321; color:#ffffff;"/>
                        <br/><br/><br/>
                        <a href="" style="text-decoration:none; font-family:Verdana, Arial, Helvetica, sans-serif; font-size:12px; font-weight:600; color:#666666; float:left;"><u>View</u></a>
                    	<br/><br/>
                    	<input type="checkbox" name="txtbox1" id="txtbox1" style="float:left;" />
                        <font style="font-family:Verdana, Arial, Helvetica, sans-serif; font-size:12px; color:#000000; float:left">Select to compare</font>
                        
                        
                    </div>
                    
              </div>
               
            
            
            </div>									<!-- 	end of item 1 div	-->
            
            
            <div style="width:660px; height:200px; border-bottom:1px #666666 dashed; padding:20px 0px 20px 0px; background-color:none;"> <!-- item 2 div	-->
            	
              <div>
                	<img src="images_diwan/2600-home.jpg" style="float:left;" />
                    
                    <div style="width:270px; height:200px; background-color:none; float:left; margin-left:20px;">
                    	
                        <font style="font-family:Verdana, Arial, Helvetica, sans-serif; float:left; font-size:12px;">Available</font>
                        <br/><br/>
                        
                        <font style="font-family:Verdana, Arial, Helvetica, sans-serif; font-size:12px; font-weight:600px; float:left; font-weight:600; color:#666666;">Diwan-e-Khaas, Diwan-e-Shaan /...</font>
                        <br/>
                        <font style="font-family:Verdana, Arial, Helvetica, sans-serif; font-size:12px; font-weight:600px; float:left; color:#666666;">For more details click on this image</font>
                    
                    </div>
                    
                    <div style="width:150px; height:200px; background-color:none; float:right;">
                    
                    	<span class="price" style="float:left;">Rs/-1,995.00</span> 
                		<br/><br/>
                        <input type="button" name="btnatc" id="btnatc" value="Add to Cart" style="float:right; border:0px; width:150px; height:40px; background-color:#694321; color:#ffffff;"/>
                        <br/><br/><br/>
                        <a href="" style="text-decoration:none; font-family:Verdana, Arial, Helvetica, sans-serif; font-size:12px; font-weight:600; color:#666666; float:left;"><u>View</u></a>
                    	<br/><br/>
                    	<input type="checkbox" name="txtbox1" id="txtbox1" style="float:left;" />
                        <font style="font-family:Verdana, Arial, Helvetica, sans-serif; font-size:12px; color:#000000; float:left">Select to compare</font>
                        
                        
                    </div>
                    
              </div>
               
            
            
            </div>									<!-- 	end of item 2 div	-->
            
            
            <div style="width:660px; height:200px; border-bottom:1px #666666 dashed; padding:20px 0px 20px 0px; background-color:none;"> <!-- item 3 div	-->
            	
              <div>
                	<img src="images_diwan/2602-home.jpg" style="float:left;" />
                    
                    <div style="width:270px; height:200px; background-color:none; float:left; margin-left:20px;">
                    	
                        <font style="font-family:Verdana, Arial, Helvetica, sans-serif; float:left; font-size:12px;">Available</font>
                        <br/><br/>
                        
                        <font style="font-family:Verdana, Arial, Helvetica, sans-serif; font-size:12px; font-weight:600px; float:left; font-weight:600; color:#666666;">Diwan-e-Khaas, Diwan-e-Shaan /...</font>
                        <br/>
                        <font style="font-family:Verdana, Arial, Helvetica, sans-serif; font-size:12px; font-weight:600px; float:left; color:#666666;">For more details click on this image</font>
                    
                    </div>
                    
                    <div style="width:150px; height:200px; background-color:none; float:right;">
                    
                    	<span class="price" style="float:left;">Rs/-1,795.00</span> 
                		<br/><br/>
                        <input type="button" name="btnatc" id="btnatc" value="Add to Cart" style="float:right; border:0px; width:150px; height:40px; background-color:#694321; color:#ffffff;"/>
                        <br/><br/><br/>
                        <a href="" style="text-decoration:none; font-family:Verdana, Arial, Helvetica, sans-serif; font-size:12px; font-weight:600; color:#666666; float:left;"><u>View</u></a>
                    	<br/><br/>
                    	<input type="checkbox" name="txtbox1" id="txtbox1" style="float:left;" />
                        <font style="font-family:Verdana, Arial, Helvetica, sans-serif; font-size:12px; color:#000000; float:left">Select to compare</font>
                        
                        
                    </div>
                    
              </div>
               
            
            
            </div>									<!-- 	end of item 3 div	-->
            
            <div style="width:660px; height:200px; border-bottom:1px #666666 dashed; padding:20px 0px 20px 0px; background-color:none;"> <!-- item 4 div	-->
            	
              <div>
                	<img src="images_diwan/2610-home.jpg" style="float:left;" />
                    
                    <div style="width:270px; height:200px; background-color:none; float:left; margin-left:20px;">
                    	
                        <font style="font-family:Verdana, Arial, Helvetica, sans-serif; float:left; font-size:12px;">Available</font>
                        <br/><br/>
                        
                        <font style="font-family:Verdana, Arial, Helvetica, sans-serif; font-size:12px; font-weight:600px; float:left; font-weight:600; color:#666666;">Diwan-e-Khaas, Diwan-e-Shaan /...</font>
                        <br/>
                        <font style="font-family:Verdana, Arial, Helvetica, sans-serif; font-size:12px; font-weight:600px; float:left; color:#666666;">For more details click on this image</font>
                    
                    </div>
                    
                    <div style="width:150px; height:200px; background-color:none; float:right;">
                    
                    	<span class="price" style="float:left;">Rs/-1,795.00</span> 
                		<br/><br/>
                        <input type="button" name="btnatc" id="btnatc" value="Add to Cart" style="float:right; border:0px; width:150px; height:40px; background-color:#694321; color:#ffffff;"/>
                        <br/><br/><br/>
                        <a href="" style="text-decoration:none; font-family:Verdana, Arial, Helvetica, sans-serif; font-size:12px; font-weight:600; color:#666666; float:left;"><u>View</u></a>
                    	<br/><br/>
                    	<input type="checkbox" name="txtbox1" id="txtbox1" style="float:left;" />
                        <font style="font-family:Verdana, Arial, Helvetica, sans-serif; font-size:12px; color:#000000; float:left">Select to compare</font>
                        
                        
                    </div>
                    
              </div>
               
            
            
            </div>									<!-- 	end of item 4 div	-->
            
            <div style="width:660px; height:200px; border-bottom:1px #666666 dashed; padding:20px 0px 20px 0px; background-color:none;"> <!-- item 5 div	-->
            	
              <div>
                	<img src="images_diwan/2619-home.jpg" style="float:left;" />
                    
                    <div style="width:270px; height:200px; background-color:none; float:left; margin-left:20px;">
                    	
                        <font style="font-family:Verdana, Arial, Helvetica, sans-serif; float:left; font-size:12px;">Available</font>
                        <br/><br/>
                        
                        <font style="font-family:Verdana, Arial, Helvetica, sans-serif; font-size:12px; font-weight:600px; float:left; font-weight:600; color:#666666;">Diwan-e-Khaas, Diwan-e-Shaan /...</font>
                        <br/>
                        <font style="font-family:Verdana, Arial, Helvetica, sans-serif; font-size:12px; font-weight:600px; float:left; color:#666666;">For more details click on this image</font>
                    
                    </div>
                    
                    <div style="width:150px; height:200px; background-color:none; float:right;">
                    
                    	<span class="price" style="float:left;">Rs/-1,795.00</span> 
                		<br/><br/>
                        <input type="button" name="btnatc" id="btnatc" value="Add to Cart" style="float:right; border:0px; width:150px; height:40px; background-color:#694321; color:#ffffff;"/>
                        <br/><br/><br/>
                        <a href="" style="text-decoration:none; font-family:Verdana, Arial, Helvetica, sans-serif; font-size:12px; font-weight:600; color:#666666; float:left;"><u>View</u></a>
                    	<br/><br/>
                    	<input type="checkbox" name="txtbox1" id="txtbox1" style="float:left;" />
                        <font style="font-family:Verdana, Arial, Helvetica, sans-serif; font-size:12px; color:#000000; float:left">Select to compare</font>
                        
                        
                    </div>
                    
              </div>
               
            
            
            </div>									<!-- 	end of item 5 div	-->
            
            <div style="width:660px; height:200px; border-bottom:1px #666666 dashed; padding:20px 0px 20px 0px; background-color:none;"> <!-- item 6 div	-->
            	
              <div>
                	<img src="images_diwan/2625-home.jpg" style="float:left;" />
                    
                    <div style="width:270px; height:200px; background-color:none; float:left; margin-left:20px;">
                    	
                        <font style="font-family:Verdana, Arial, Helvetica, sans-serif; float:left; font-size:12px;">Available</font>
                        <br/><br/>
                        
                        <font style="font-family:Verdana, Arial, Helvetica, sans-serif; font-size:12px; font-weight:600px; float:left; font-weight:600; color:#666666;">Diwan-e-Khaas, Diwan-e-Shaan /...</font>
                        <br/>
                        <font style="font-family:Verdana, Arial, Helvetica, sans-serif; font-size:12px; font-weight:600px; float:left; color:#666666;">For more details click on this image</font>
                    
                    </div>
                    
                    <div style="width:150px; height:200px; background-color:none; float:right;">
                    
                    	<span class="price" style="float:left;">Rs/-1,795.00</span> 
                		<br/><br/>
                        <input type="button" name="btnatc" id="btnatc" value="Add to Cart" style="float:right; border:0px; width:150px; height:40px; background-color:#694321; color:#ffffff;"/>
                        <br/><br/><br/>
                        <a href="" style="text-decoration:none; font-family:Verdana, Arial, Helvetica, sans-serif; font-size:12px; font-weight:600; color:#666666; float:left;"><u>View</u></a>
                    	<br/><br/>
                    	<input type="checkbox" name="txtbox1" id="txtbox1" style="float:left;" />
                        <font style="font-family:Verdana, Arial, Helvetica, sans-serif; font-size:12px; color:#000000; float:left">Select to compare</font>
                        
                        
                    </div>
                    
              </div>
               
            
            
            </div>									<!-- 	end of item 6 div	-->
            
            <div style="width:660px; background-color:none; height:40px;">
            	<br/>
                <input type="button" name="btncompare" id="btncompare" value="Compare" style="border:0px; width:100px; height:40px; background-color:#8B0F01; color:#ffffff; float:right;"/>
                
            </div>
            
        </div>
        
    </div>																					<!--	end of content div	-->
    
    
    <div id="vertmenu" style="float:left; background-color:none; border:0px solid #CCFF33; padding-left:40px; padding-right:40px; width:244px; height:2000px;">	<!--vertical side menu div	-->
		
        <br/><font style="font-size:24px; float:left;">On Swayam India</font><br/><br/>
        
      <ul>
            <li><a href="#" tabindex="1">SWAYAM Price List</a></li>
            <li><a href="#" tabindex="2">Write to Us</a></li>
            <li><a href="#" tabindex="3">About us</a></li>
            <li><a href="#" tabindex="4">Salient Features</a></li>
            <li><a href="#" tabindex="5">Cotton Care</a></li>
            <li><a href="#" tabindex="6">Customer Policy</a></li>
            <li><a href="#" tabindex="3">FAQs</a></li>
            <li><a href="#" tabindex="4">Return Policy</a></li>
            <li><a href="#" tabindex="5">Privacy Policy</a></li>
            <li><a href="#" tabindex="6">Terms and Conditions</a></li>
      </ul>
        
        <br/><br/>
        <img src="add-to-cart-web-button-thumb9227672.jpg" style="float:left;" />
        <font style="font-size:22px; text-align:left; float:left;">&nbsp;&nbsp;Cart</font>
        <br/><br/><br/>
		<font style="font-family: Verdana, Arial, Helvetica, sans-serif; font-size: 15px; font-weight:600; float:left; border-bottom: 1px dashed #666666; padding:5px 0px 5px 0px; width:244px; text-align:left;">No products</font>
        
        
		<div style="width:244px; background-color:none; float:left; height:75px; border-bottom: 1px dashed #666666; padding:5px 0px 5px 0px; ">
        	
            	<div style="width:122px; background-color:none; float:left; height:75px;">
                	
                    <font style="font-family: Verdana, Arial, Helvetica, sans-serif; font-size: 15px; color:#666666; float:left;">Shipping</font>
                    <br/>
                    <font style="font-family: Verdana, Arial, Helvetica, sans-serif; font-size: 15px; color:#666666; float:left;">Tax</font>
                    <br/>
                    <font style="font-family: Verdana, Arial, Helvetica, sans-serif; font-size: 15px; color:#666666; float:left;">Total</font>
            	</div>
                
                
                
                <div style="width:122px; background-color:none; float:left; height:75px;">
                	
                    <font style="font-family: Verdana, Arial, Helvetica, sans-serif; font-size: 15px; font-weight:600; float:left; float:right;">Rs/-0.00</font>
                    <br/>
                    <font style="font-family: Verdana, Arial, Helvetica, sans-serif; font-size: 15px; font-weight:600; float:left; float:right;">Rs/-0.00</font>
                    <br/>
                    <font style="font-family: Verdana, Arial, Helvetica, sans-serif; font-size: 15px; font-weight:600; float:left; float:right;">Rs/-0.00</font>
            	</div>
                
                
               
        	
        </div>
        
        <font style="font-family: Verdana, Arial, Helvetica, sans-serif; font-size: 15px; font-weight:600; float:left; width:244px; text-align:left;">Prices are Tax included</font>
        <br/><br/><br/>
        
        <div style="width:244px; height:60px; float:left; margin-top:10px;">
        
        	<input type="button" name="btncart" id="btncart" value="Cart" style="float:left; border:0px; width:100px; height:40px; background-color:#694321; color:#ffffff; margin-right:1px;"/>
            
            <input type="button" name="btncheckout" id="btncheckout" value="Checkout" style="float:left; border:0px; width:100px; height:40px; background-color:#8B0F01; color:#ffffff;"/>
        
        </div>
        
        
        
                
    	<div style="width:244px; height:1000px; float:left; background-color:none;">
    
    	<img src="images3/slide_03.jpg" />
    
    	</div>    

	
	</div>																<!-- 	end of vertical side menu div	-->
    
    


</div>																								<!--	end of page div		-->
</center>



</body>
</html>
